1) Instances file：
The instances in the FPBS_QAP program is stored in the "instances" directory, where the instances belong to two datasets: EASYS and HARDS.

2) Input parameters 
The program FPBS_QAP contains following input parameters, where instance_name is the the file name of an instance, 
dataset is the dataset where the instance is in, best_known_cost is the current best-known cost of the instance, 
nbr_repeats is the times of runs, and limit_time is the time limit (in seconds) for each run of FPBS_QAP algorithm:
————————————————————————————————————————
./dmbmaqap instance_name dataset best_known_cost nbr_repeats limit_time
————————————————————————————————————————

3) Computational results: 
The computational results are summarized in a csv file named "dataset_result.csv", where dataset is the dataset name. 
and for each instance the following information is given:
——————————————————————————————————————————————————————————————————————————
instance_name     best_known_cost      best_cost      avg_cost      avg_time       nbr_succ    avg_gen	best_pd	avg_pd	worst_pd
——————————————————————————————————————————————————————————————————————————
where instance_name is the the file name of an instance, best_known_cost is the current best-known cost of the instance, 
best_cost, avg_cost and avg_time represent respectively the best, average objective values and the average computational time (in seconds) over 'NbrRepeats' runs,
nbr_succ is the number of times that best_cost is obtained, avg_gen is the average generation of best values obtained (not always "best_cost") in each run , 
and best_pd, avg_pd and worst_pd represent respectively the best, average and worst percentage deviation for each run of the algorithm.   

4) Statistics file：
The best solution found is stored in a text file named "instance_*.out", where instance is the file name of an instance, and * is some setting of the experiment.
There are three areas for each experiment, the format of statistics file is as follows: 
The first area contains the objective value, computational time (in seconds) and the generation of best values obtained for each run. 
In second area, the first area contains best_cost, avg_cost, nbr_succ and avg_time and avg_gen. The second line contains best_pd, avg_pd and worst_pd. 
The last area contains the solution in detail. 

5) Elites and patterns file：
The elite solutions set to be mined and patterns mined is stored in text files respectively named "instance_elites.txt" and "instance_patterns.txt", where instance is the file name of an instance. 
But this two files is overwritten with the updating of elite solutions and patterns mined.