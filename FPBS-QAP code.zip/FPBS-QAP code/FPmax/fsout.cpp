#include "fsout.h"
#include "common.h"

#include <sstream>

FSout::FSout()
{
	s = "";
}

FSout::~FSout()
{
}

int FSout::isOpen()
{
	return 1;
}

void FSout::printSet(int length, int *iset, int support)
{
	//cout << "printSet!!" << endl;

	stringstream str;

	for(int i=0; i<length; i++)
		str << order_item[iset[i]] << " ";

	str <<  support << endl;

	//cout << "printSet " <<str.str() << endl;

	s = s + str.str();
}

void FSout::printset(int length, int *iset)
{

	cout << "printset!!" << endl;

	stringstream str;

	for(int i=0; i<length; i++)
		str << order_item[iset[i]] << " ";

	cout << "printset " << str.str() << endl;

	s = s + str.str();
}

void FSout::close()
{
}

