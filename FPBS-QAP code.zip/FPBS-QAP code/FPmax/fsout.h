#ifndef _FSOUT_CLASS
#define _FSOUT_CLASS

#include <stdio.h>
#include <iostream>

using namespace std;

class FSout
{

private:
	string s;

public:

	FSout();
	~FSout();

	int isOpen();

	void printset(int length, int *iset);
	void printSet(int length, int *iset, int support);
	void close();

	string retornaString(){return s;};

};

#endif

