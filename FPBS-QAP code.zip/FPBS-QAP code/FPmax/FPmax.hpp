/*
 * FPmax.h
 *
 *  Created on: 25/11/2009
 *      Author: Igor Machado Coelho
 *
 */

#ifndef FPMAX_H_
#define FPMAX_H_

#include <stdio.h>
#include <string>
#include <assert.h>
#include <stdlib.h>
#include <iostream>
#include <fstream>
#include <iomanip>
#include <time.h>
#include "common.h"
#include "buffer.h"
#include "Scanner.h"

#include <vector>

using namespace std;

#define LINT sizeof(int)

int *ITlen;
int* bran;
int* prefix;

int* order_item;		// given order i, order_item[i] gives itemname
int* item_order;		// given item i, item_order[i] gives its new order

//	order_item[item_order[i]]=i; item_order[order_item[i]]=i;
bool* current_fi;
int* compact;
int* supp;

MFI_tree** mfitrees;
CFI_tree** cfitrees;

stack* stklst;
int TRANSACTION_NO;
int ITEM_NO;
int THRESHOLD;

memory* fp_buf;


class FPmax
{
private:



	void printLen()
	{
		int i, j;
		for(i=ITEM_NO-1; i>=0&&ITlen[i]==0; i--);
		for(j=0; j<=i; j++)
			printf("%d\n", ITlen[j]);
	}



public:
	FPmax(){};
	// the first item of "pair" represents the elements of the pattern and the second show its support.
	vector<pair<vector<int>*,int> >* mine(vector<vector<int>* >* db, double supMin)
	{
		//cout << "mine()" << endl;

		// ================
		// Initialization
		// ================

		TRANSACTION_NO = 0;
		ITEM_NO =100;

		// ================

		THRESHOLD = (int) (supMin * db->size());
		cout << "FPmax THRESHOLD = "<<THRESHOLD<<endl;

		int i;
		FI_tree* fptree;

		Data* fdat=new Data(db);
		//Data* fdat=new Data("chess.dat");
		if(!fdat->isOpen())
		{
			cerr << "vector" << " could not be opened!" << endl;
			return new vector<pair<vector<int>*,int> >;
		}

		fp_buf=new memory(60, 4194304L, 8388608L, 2);

		fptree = (FI_tree*)fp_buf->newbuf(1, sizeof(FI_tree));
		fptree->init(-1, 0);
		fptree -> scan1_DB(fdat);
		ITlen = new int[fptree->itemno];
		
		bran = new int[fptree->itemno];
		compact = new int[fptree->itemno];
		prefix = new int[fptree->itemno];

		stklst=new stack(fptree->itemno);

		assert(stklst!=NULL && bran!=NULL && compact!=NULL && ITlen!=NULL && prefix!=NULL);

		for(i =0; i < fptree->itemno; i++)
		{
			ITlen[i] = 0L;
			bran[i] = 0;
		}
		cout << "-------------> "<< db->size() << endl;
		fptree->scan2_DB(fdat);
		fdat->close();


		FSout* fout;

		//fout = new FSout("saida.txt");
		fout = new FSout();


		if(fptree->Single_path())
		{
			cout << "Single Path" << endl;
			return new vector<pair<vector<int>*,int> >;
		}


		current_fi = new bool[fptree->itemno];
		supp=new int[fptree->itemno];		//for keeping support of items
		assert(supp!=NULL&&current_fi!=NULL);

		for(i = 0; i<fptree->itemno; i++)
		{
			current_fi[i] = false;
			supp[i]=0;
		}

		MFI_tree* LMFI;
		mfitrees = (MFI_tree**)new MFI_tree*[fptree->itemno];
		memory* Max_buf=new memory(40, 1048576L, 5242880, 2);
		LMFI = (MFI_tree*)Max_buf->newbuf(1, sizeof(MFI_tree));
		LMFI->init(Max_buf, fptree, NULL, NULL, -1);
		fptree->set_max_tree(LMFI);
		mfitrees[0] = LMFI;
		fptree->FPmax(fout);

		//printLen();
		if(fout)
			fout->close();

		//	delete fp_buf;
		delete stklst;
		delete []current_fi;
		delete []supp;

		// ===================================

		string s = fout->retornaString();

		// ===================================
		
		vector<vector<int>* >* v = new vector<vector<int>* >();
		Scanner sLine(s);
		
		while(sLine.hasNext())
		{
			string s1 = sLine.nextLine();
			Scanner sc_str(s1);
			vector<int>* t = new vector<int>();
			while(sc_str.hasNext())
				t->push_back(sc_str.nextInt());
			v->push_back(t);
		}
		
		vector<pair<vector<int>*, int > >* saida = new vector<pair<vector<int>*, int > >();

		for(unsigned int i=0;i<v->size();i++)
		{
			int sup = v->at(i)->back();
			v->at(i)->pop_back();

			saida->push_back(pair<vector<int>*,int >(v->at(i),sup));
		}


		return saida;
	};

	virtual ~FPmax(){};
};

#endif /* FPMAX_H_ */
