#!/bin/bash
#SourceFile=./src/MACCCNP.cpp
ExecuteFile=dmbmaqap
Dataset="HARDS"
NbrRepeats=10
LimitTIme=10800

###Compile the source file
# g++ ${SourceFile} -o ${ExecuteFile} -O3

for var in taskJun2017_*
do
 rm ${var}; 
done

for var in core.*
do
 rm ${var}; 
done

for var in *.txt
do
 rm ${var}; 
done

InstancePath="./instances/"${Dataset}"/*.dat"
ResultPath="./results/"${Dataset}"/*.res*"
StatisticsPath="./statistics/"${Dataset}"/*.sum*"

for var in ${ResultPath}
do
 rm ${var}; 
done

for var in ${StatisticsPath}
do
 rm ${var}; 
done

for FILE in ${InstancePath}
do
	InstanceFile=${FILE##*/}
   case ${InstanceFile} in
   # Type II
   tai40a.dat) BestKnownCost=3139370
               ;;
   tai50a.dat) BestKnownCost=4938796
               ;;
   tai60a.dat) BestKnownCost=7205962
               ;;
   tai80a.dat) BestKnownCost=13499184
               ;;
   tai100a.dat) BestKnownCost=21052466
                ;;
   # Type III
   tai50b.dat) BestKnownCost=458821517
               ;;
   tai60b.dat) BestKnownCost=608215054
               ;;
   tai80b.dat) BestKnownCost=818415043
               ;;
   tai100b.dat) BestKnownCost=1185996137
               ;;
   tai150b.dat) BestKnownCost=498896643
                ;;
   # Type IV
   sko72.dat) BestKnownCost=66256
              ;;
   sko81.dat) BestKnownCost=90998
              ;;
   sko90.dat) BestKnownCost=115534
              ;;
   sko100a.dat) BestKnownCost=152002
                ;;
   sko100b.dat) BestKnownCost=153890
                ;;
   sko100c.dat) BestKnownCost=147862
                ;;
   sko100d.dat) BestKnownCost=149576
                ;;
   sko100e.dat) BestKnownCost=149150
                ;;
   sko100f.dat) BestKnownCost=149036
                ;;
   wil100.dat) BestKnownCost=273038
               ;;
   tho150.dat) BestKnownCost=8133398
                ;;             
               *) echo 'error occurs'
                  ;;
   esac
   Task="taskJun2017_"${InstanceFile}".sh"
   echo "#!/bin/bash
   ./${ExecuteFile}" ${InstanceFile} ${Dataset} ${BestKnownCost} ${NbrRepeats} ${LimitTIme}> ${Task}
   chmod 700 ${Task}
   # Submit the tasks
   qsub -cwd -pe param 1 -q "intel-E5-2670" ${Task}
   # Delete the submitted files
	rm -f ${Task}
   sleep 1
done