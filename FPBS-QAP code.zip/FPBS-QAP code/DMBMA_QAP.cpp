//============================================================================
// Name        : FPBS_QAP.cpp
// Author      : Yangming Zhou (zhou.yangming@yahoo.com)
// Version     : 07 June 2017
// Copyright   : LERIA, Faculty of Science, University of Angers, Angers, France
// Description : Frequent pattern based search for quadratic assignment problem
//============================================================================
#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <sstream>
#include <fstream>
#include <string.h>
#include <map>
#include <cmath>
#include <string.h>
#include <vector>
#include "FPmax/FPmax.hpp"

#define PS 15				// population size
#define max_int 2147483647
#define epsilon 0.0001
#define nbr_patterns 11		// number of patterns
#define min_support 2		// minimum support
#define max_nbr_selects 2	// tournament pool size

#define sdf_abs(X)  (((X) < 0) ? -(X) : (X))

using namespace std;

typedef int * type_vector;
typedef long **type_matrix;
typedef unsigned short int **type_matrix_s;

char *instance_name; 			// instance file name
char *dataset;					// data set
char statistic_path[100];		// statistical file path
char instance_path[100];		// instance file path
char elite_set_path[100];
char pattern_set_path[100];

int n;                    		// problem size
type_matrix flow, dist;     	// flows and distances matrices

double initial_ptr;
double perturb_str;
long iteration = 0;
clock_t begin_time;

type_matrix_s Pop;  		//Population of individuals
type_matrix_s parent_pool;
long *Pop_costs;
double *Pop_times;

type_vector child_sol;  	// solution (permutation)
double child_time;
long child_cost;        	// solution cost
type_vector best_sol;
double best_time;
long best_cost;
long best_gens;
long best_known_cost;
int nbr_repeats;
double limit_time;

struct pattern
{
	int PV[300];		// Patter Vector;
	int length;			// length of pattern
	int support;		// support of pattern
}
typedef Pattern;

vector<Pattern> patternList;		// List of patterns mined by FPmax

void read_instance()
{
	ifstream FIC;
    FIC.open(instance_path);
    if(FIC.fail())
    {
    	cout << "### Fail to open file: " << instance_name << endl;
        getchar();
        exit(0);
    }
    if(FIC.eof())
    {
    	cout << "### Fail to open file: " << instance_name << endl;
        exit(0);
    }
    // the size of a permutation
	FIC >> n;

	Pop = new unsigned short int *[PS+1];
	for(int i = 0; i <= PS; i++) Pop[i] = new unsigned short int[n+1];;
	Pop_costs = new long[PS+1];
	Pop_times = new double[PS+1];
	child_sol = new int[n+1];
	best_sol = new int[n+1];

	flow = new long *[n+1];
	dist = new long *[n+1];
	for(int i = 1; i <= n; i++)
	{
		flow[i] = new long[n+1];
		dist[i] = new long[n+1];
	}

	/************** read flows and distances matrices **************/
	for(int i = 1; i <= n; i++)
		for(int j = 1; j <= n; j++)
			FIC >> flow[i][j];

	for(int i = 1; i <= n; i++)
		for(int j = 1; j <= n; j++)
			FIC >> dist[i][j];

    FIC.close();
}

void clear_up()
{
	delete [] child_sol;
	delete [] best_sol;
	delete [] Pop_costs;
	delete [] Pop_times;
	for(int i = 0; i < PS+1; i++)
		delete Pop[i];

	for(int i = 0; i < n+1; i++)
	{
		delete flow[i];
		delete dist[i];
	}
}

void output_results(long n, char*file_name, long costs[], int nbr_runs, long best_cost, type_vector & sol, double times[], long gens[])
{
	double worst_cost;
    double avg_cost;
    double avg_pd,best_pd,worst_pd;
    double avg_time = 0.0;
    double avg_gen = 0.0;
    int nbr_succ = 0;	// number of best solutions found

    avg_cost = 0;
    worst_cost = -1;
    for(int i = 0; i < nbr_runs; i++)
    {
    	avg_cost += costs[i];
        avg_time += times[i];
        avg_gen += gens[i];

        if(costs[i] == best_known_cost)
        	nbr_succ++;

        if(costs[i] > worst_cost)
        	worst_cost = costs[i];
    }

    avg_time /= static_cast<double>(nbr_runs);
    avg_cost /= static_cast<double>(nbr_runs);
    avg_gen /= static_cast<double>(nbr_runs);

    // calculate percentage deviation
    avg_pd = 100.0*(static_cast<double>(avg_cost-best_known_cost))/static_cast<double>(best_known_cost);
    best_pd = 100.0*(static_cast<double>(best_cost-best_known_cost))/static_cast<double>(best_known_cost);
    worst_pd = 100.0*(static_cast<double>(worst_cost-best_known_cost))/static_cast<double>(best_known_cost);

    ofstream out;
    out.open(file_name);
    for(int i = 0; i < nbr_runs; i++)
    {
    	out << costs[i] << " " << times[i] << " " << gens[i] << endl;
    }
    out << "--------------------------------------------------------" << endl;
    out << best_cost << ", " << avg_cost << ", " << nbr_succ << ", " << avg_time << "," << avg_gen << ", " << endl;
    out << best_pd << ", " << avg_pd << ", " << worst_pd << endl;
    // store the best solution found so far
    out << "--------------------------------------------------------" << endl;
    for(int i = 1; i <= n; i++)
    	out << sol[i] << " ";
    cout << endl;
    out.close();

	FILE *fin;
	char final_result_file[200];
    strcpy(final_result_file,dataset);
	strcat(final_result_file,"_result.csv");
	fin = fopen(final_result_file,"at+");
	if(fin != NULL)
	{
		fprintf(fin,"%s, %ld, %ld, %f, %f, %d, %f, %f, %f, %f\n",instance_name,best_known_cost,best_cost,avg_cost,avg_time,nbr_succ,avg_gen,best_pd,avg_pd,worst_pd);
	}
	fclose(fin);
}

double determine_initial_ptr(char*filename)
{
	double initial_str;

    if(strcmp(filename,"tai50b.dat") == 0 || strcmp(filename,"tai60b.dat") == 0 || strcmp(filename,"tai80b.dat") == 0 || strcmp(filename,"tai100b.dat") == 0 || strcmp(filename,"tai150b.dat") == 0)
    {
    	initial_str = 0.15; // for Type III
    }
    else if(strcmp(filename,"sko72.dat") == 0 || strcmp(filename,"sko81.dat") == 0 || strcmp(filename,"sko90.dat") == 0 || strcmp(filename,"wil100.dat") == 0 || strcmp(filename,"tho150.dat") == 0)
    {
    	initial_str = 0.15; // for Type IV
    }
    else if(strcmp(filename,"sko100a.dat") == 0 || strcmp(filename,"sko100b.dat") == 0 || strcmp(filename,"sko100c.dat") == 0 || strcmp(filename,"sko100d.dat") == 0 || strcmp(filename,"sko100e.dat") == 0 || strcmp(filename,"sko100f.dat") == 0)
    {
    	initial_str = 0.15; // for Tyoe IV
    }
    else
    	initial_str = 0.05;

	return initial_str;
}

void transpose(int & a, int & b)
{
	long temp = a;
	a = b;
	b = temp;
}

/*--------------------------------------------------------------*/

/*       compute the cost difference if elements i and j        */

/*         are transposed in permutation (solution) p           */

/*--------------------------------------------------------------*/

long compute_delta(int n, type_matrix & a, type_matrix & b, type_vector & p, int i, int j)
{
	long delta;
	delta = (a[i][i]-a[j][j])*(b[p[j]][p[j]]-b[p[i]][p[i]]) + (a[i][j]-a[j][i])*(b[p[j]][p[i]]-b[p[i]][p[j]]);

	for(int k = 1; k <= n; k++)
		if(k != i && k != j)
		{
			delta += (a[k][i]-a[k][j])*(b[p[k]][p[j]]-b[p[k]][p[i]]) + (a[i][k]-a[j][k])*(b[p[j]][p[k]]-b[p[i]][p[k]]);
		}

  return delta;
 }


/*--------------------------------------------------------------*/

/*      Idem, but the value of delta[i][j] is supposed to       */

/*    be known before the transposition of elements r and s     */

/*--------------------------------------------------------------*/

long compute_delta_part(type_matrix & a, type_matrix & b, type_vector & p, type_matrix & delta, int i, int j, int r, int s)
{
	long dist;
	dist = delta[i][j] + (a[r][i]-a[r][j]+a[s][j]-a[s][i]) * (b[p[s]][p[i]]-b[p[s]][p[j]]+b[p[r]][p[j]]-b[p[r]][p[i]]) +
     (a[i][r]-a[j][r]+a[j][s]-a[i][s]) * (b[p[i]][p[s]]-b[p[j]][p[s]]+b[p[j]][p[r]]-b[p[i]][p[r]]);

	return dist;
}

void update_matrix_of_move_cost(int i_retained, int j_retained,long n, type_matrix & delta, type_vector & p, type_matrix & a, type_matrix & b)
{
     for(int i = 1; i < n; i++)
    	 for(int j = i+1; j <= n; j++)
    	 {
    		 if(i != i_retained && i != j_retained && j != i_retained && j != j_retained)
    			 delta[i][j] = compute_delta_part(a, b, p, delta, i, j, i_retained, j_retained);
    		 else
    			 delta[i][j] = compute_delta(n, a, b, p, i, j);
    	 }
}

void perturb(type_vector & p, long n, type_matrix & delta, long & current_cost, type_matrix & a, type_matrix & b,
             type_matrix & last_swaped, type_matrix & frequency, int no_improve_iter, long & improved_cost)
{
	int i_retained = -1, j_retained = -1, min_delta;
	long cost = current_cost;

	int bit = 0;
   	double d = static_cast<double>(no_improve_iter)/249;
   	double e = pow(2.718, -d);
   	if(e < 0.75) e = 0.75;
   	if(e > (static_cast<double>(rand()%101)/100.0))
   		bit = 1;

   	for(int k = 0; k < perturb_str; k++)
   	{
   		if(bit == 1)
   		{
   			min_delta = 999999999;
   			for(int i = 1; i < n; i++)
   				for(int j = i+1; j <= n; j++)
   				{
   					if((current_cost + delta[i][j]) != cost && delta[i][j] < min_delta && ((last_swaped[i][j] + n*0.9 + rand()%(static_cast<int>(n*0.2))) < iteration || (current_cost + delta[i][j]) < improved_cost))
   					{
   						i_retained = i;
   						j_retained = j;
   						min_delta = delta[i][j];

   						if((current_cost + delta[i][j]) < improved_cost)
   							improved_cost = current_cost + delta[i][j];
   					}
   				}
   		}
   		else
   		{
   			i_retained = 1 + rand()%n;
            j_retained = 1 + rand()%n;
            if(i_retained > j_retained)
            	swap(i_retained, j_retained);

            while(i_retained == j_retained || (current_cost + delta[i_retained][j_retained]) == cost)
            {
            	j_retained = 1 + rand()%n;
            	if(i_retained > j_retained)
            		swap(i_retained, j_retained);
            }
   		}

   		if(i_retained != -1 && j_retained != -1)
   		{
   			last_swaped[i_retained][j_retained] = iteration;
   			frequency[i_retained][j_retained] += 1;
   			transpose(p[i_retained], p[j_retained]);
   			current_cost += delta[i_retained][j_retained];
   			update_matrix_of_move_cost(i_retained, j_retained, n, delta, p, a, b);
   		}
   		iteration++;
   	}
}

void breakout_local_search(long n,           // problem size
                 type_matrix & a,        	 // flows matrix
                 type_matrix & b,            // distance matrix
                 type_vector & improved_sol, // best solution found
                 long & improved_sol_cost,   // cost of best solution
                 long max_nbr_iters,		 // maximum number of iterations
                 double & improved_sol_time) // time to find the improved solution
{
	type_vector sol;                        // current solution
	type_matrix delta;                    	// store move costs
	type_matrix last_swaped;
	type_matrix frequency;
	long sol_cost;                    // current solution cost
	long iter;
	int no_improve_iter = 0;
	int i_retained, j_retained;  // indices
	perturb_str = initial_ptr*n;

	bool perturbed_once = false;
	long previous_cost = 1;
	iteration = 0;

	/***************** dynamic memory allocation *******************/
	sol = new int[n+1];
	delta = new long*[n+1];
	last_swaped = new long*[n+1];
	frequency = new long*[n+1];
	for(int i = 1; i <= n; i++)
	{
		delta[i] = new long[n+1];
		last_swaped[i] = new long[n+1];
		frequency[i] = new long[n+1];
	}

	/************** current solution initialization ****************/

	for(int i = 1; i <= n; i = i + 1)
		sol[i] = improved_sol[i];

	for(int i = 1; i <= n; i++)
		for(int j = 1; j <= n; j++)
		{
			last_swaped[i][j] = 0;
			frequency[i][j] = 0;
		}

	/**************** and matrix of cost of moves  *****************/

	sol_cost = 0;
	for(int i = 1; i <= n; i++)
		for(int j = 1; j <= n; j++)
		{
			sol_cost += a[i][j]*b[sol[i]][sol[j]];
			if(i < j)
			{
				delta[i][j] = compute_delta(n, a, b, sol, i, j);
			}
		}
	improved_sol_cost = sol_cost;

	/******************** main tabu search loop ********************/
	iter = 1;
	while(iter <= max_nbr_iters)
	{
		/** find best move (i_retained, j_retained) **/
		i_retained = max_int;       // in case all moves are tabu
		long min_delta = max_int;   // retained move cost

		for(int i = 1; i < n; i++)
			for(int j = i+1; j <= n; j++)
			{
				if(delta[i][j] < min_delta)
				{
					i_retained = i;
					j_retained = j;
					min_delta = delta[i][j];
				}
			}

		if((sol_cost + delta[i_retained][j_retained]) < sol_cost)
		{
			transpose(sol[i_retained], sol[j_retained]);
			last_swaped[i_retained][j_retained] = iteration;
			frequency[i_retained][j_retained] += 1;
			iteration++;
			sol_cost += delta[i_retained][j_retained];

			// best solution improved ?
			if(sol_cost < improved_sol_cost)
			{
				improved_sol_cost = sol_cost;
				improved_sol_time = (clock() - begin_time)/static_cast<double>(CLOCKS_PER_SEC);
            	for(int k = 1; k <= n; k = k+1)
            		improved_sol[k] = sol[k];

				no_improve_iter = 0;
			}
			update_matrix_of_move_cost(i_retained, j_retained, n, delta, sol, a, b);
			perturbed_once = false;
		}
		else
		{
			if(no_improve_iter > 250)
			{
				no_improve_iter = 0;
				perturb_str = n*(0.2 + (static_cast<double>(rand()%20)/100.0));
			}
			else if((perturbed_once == false && previous_cost != sol_cost) || (perturbed_once && previous_cost != sol_cost)) // Escaped from the previous local optimum. New local optimum reached
			{
				no_improve_iter++;
				perturb_str = ceil(n*initial_ptr);
				if(perturb_str < 2)
					perturb_str = 2;
			}
			else if(previous_cost == sol_cost)
			{
				perturb_str += 1;
			}

			previous_cost = sol_cost;
			perturb(sol,n, delta, sol_cost, a, b, last_swaped, frequency, no_improve_iter, improved_sol_cost);
			perturbed_once = true;
		}

		// check the running time
		if((clock() - begin_time)/static_cast<double>(CLOCKS_PER_SEC) > limit_time)
			break;

		iter++;
	}

	// free memory
	delete[] sol;
	for(int i = 1; i <= n; i++)
	{
		delete [] frequency[i];
		delete [] delta[i];
		delete [] last_swaped[i];
	}
	delete [] delta;
	delete [] frequency;
	delete [] last_swaped;
} // tabu

void initialize_pool(long n, int pop_size, type_matrix_s & pop)
{
    for(int i = 0; i < pop_size; i++)
    {
    	// a random permutation
    	for(int j = 0; j <= n; j++)
    		pop[i][j] = j;

    	for(int j = 1; j < n; j++)
    		swap(pop[i][j], pop[i][j + rand()%(n-j+1)]);
    }
}

bool update_pool_unique(long n, type_vector & child_sol, long child_cost, double child_time, type_matrix_s & pop,  long *pop_costs, int pop_size)
{
	bool is_updated = false;
	int min_dist, sol_dist;
	long long max_cost;
	int index_worst;

	// the distance to the closest individual in the population
	min_dist = max_int;
    for(int i = 0; i < pop_size; i++)
    {
    	sol_dist = 0;
    	for(int j = 1; j <= n; j++)
    	{
    		if(pop[i][j] != child_sol[j])
    			sol_dist++;
        }

        if(sol_dist < min_dist)
        	min_dist = sol_dist;
    }

    // the worst individual in the population
    max_cost = 0;
    for(int i = 0; i < pop_size; i++)
    {
    	if(pop_costs[i] > max_cost)
    	{
    		max_cost = pop_costs[i];
    		index_worst = i;
    	}
    }

    // replace the worst individual in the population
    if(min_dist > 0 && child_cost < max_cost)
    {
    	pop_costs[index_worst] = child_cost;
    	for(int i = 1; i <= n; i++)
    		pop[index_worst][i] = child_sol[i];
    	is_updated = true;
    }

    // update the best solution
    if(child_cost < best_cost)
    {
    	best_cost = child_cost;
    	best_time = child_time;
    	for(int i = 1; i <= n; i++)
    		best_sol[i] = child_sol[i];
    }
    return is_updated;
}

bool update_pool_greedy(long n, type_vector & child_sol, long child_cost, double child_time, type_matrix_s & pop,  long *pop_costs, int pop_size)
{
	bool is_updated = false;
	long long max_cost;
	int index_worst;

    // the worst individual in the population
    max_cost = 0;
    for(int i = 0; i < pop_size; i++)
    {
    	if(pop_costs[i] > max_cost)
    	{
    		max_cost = pop_costs[i];
    		index_worst = i;
    	}
    }

    // replace the worst individual in the population
    if(child_cost < max_cost)
    {
    	pop_costs[index_worst] = child_cost;
    	for(int i = 1; i <= n; i++)
    		pop[index_worst][i] = child_sol[i];
    	is_updated = true;
    }

    // update the best solution
    if(child_cost < best_cost)
    {
    	best_cost = child_cost;
    	best_time = child_time;
    	for(int i = 1; i <= n; i++)
    		best_sol[i] = child_sol[i];
    }
    return is_updated;
}


void best_individual(int n, type_matrix_s pop, long* pop_costs, double* pop_times, int pop_size)
{
	long long min_sol_cost = 99999999999ll;
    int best_sol_index;
    for(int i = 0; i < pop_size; i++)
    {
    	if(pop_costs[i] < min_sol_cost)
    	{
    		min_sol_cost = pop_costs[i];
    		best_sol_index = i;
    	}
    }

    if(min_sol_cost < best_cost)
    {
    	best_cost = min_sol_cost;
    	best_time = pop_times[best_sol_index];
    	for(int i = 1; i <= n; i++)
    		best_sol[i] = pop[best_sol_index][i];
    }
}

long local_optimize(long n, int pop_size, type_matrix_s & pop, long* pop_cost, double*pop_time,type_matrix & a, type_matrix & b, double sol_time, long max_iters)
{
	type_vector sol = new int[n+1];
	long sol_cost;

	for(int i = 0; i < pop_size; i++)
	{
		for(int j = 1; j <= n; j++)
			sol[j] = pop[i][j];

		// Breakout local search with max_iter = 5000
		breakout_local_search(n, a, b, sol, sol_cost, max_iters, sol_time);
		pop_cost[i] = sol_cost;
		pop_time[i] = sol_time;

		for(int j = 1; j <= n; j++)
			pop[i][j] = sol[j];

		if(sol_cost < best_cost)
		{
			best_cost = sol_cost;
			best_time = sol_time;
			for(int j = 1; j <= n; j++)
				best_sol[j] = sol[j];
		}

		if(best_cost <= best_known_cost)
			return best_cost;

	}
	delete [] sol;

	return best_cost;
}

void mine_frequent_patterns()
{
	// Step1:
	char temp_path[100];
	strcpy(temp_path,"_");
	strcat(temp_path,instance_name); // result file path
	strcat(temp_path,"_");
	char str[10];
	sprintf(str,"%d",rand()%2147483647);
	//cout << "str = " << str << endl;
    strcat(temp_path,str);
    //cout << "temp_path " << temp_path << endl;

	// Step1: store the elite solutions into eliteset.txt file
	ofstream fpin(elite_set_path);
	if(!fpin)
	{
		cout << "Cannot open the file!" << endl;
		exit(-1);
	}

	// map a permutation into a number of node pairs
	int f;
	int x,y;
	for(int i = 0; i < PS; i++)
	{
		f = 0;
		while(f < n)
		{
			x = f;
			y = Pop[i][f+1] - 1;
			fpin << (x*n + y) << " ";
			f++;
		}
		fpin << "\n";
	}
	fpin.close();

	// Step2: mine frequent patterns by FPmax algorithm
	ostringstream buffer;
	buffer.str("");
	//fpmax_hnmp <seed> <id_arq_tmp> <database> <tam. do banco> <minimum support> <nubmer of patterns> <output file>
	//buffer << "./fpmax_hnmp " << "1 " << rand()%100 << " eliteset.txt " << PS << " " << min_support << " " << nbr_patterns << " pattern.txt";
	buffer << "./fpmax_hnmp " << "1 " << temp_path << " " << elite_set_path << " " << PS << " " << min_support << " " << nbr_patterns << " " << pattern_set_path;
	//buffer << "./fim_maximal " << "bd.txt " << dadosMD.freq_supp << " padroes.txt" ;
	system(buffer.str().c_str());
	buffer.str("");

	// Step3: read mined patterns by re-map them into a partial solution
	FILE *fpout = fopen(pattern_set_path,"r");
	if(!fpout)
	{
		printf("Can not open the file!\n");
		exit(1);
	}

	int pattern_support,pattern_lenght;
	int r,t;
	r = fscanf(fpout, "%d;%d;", &pattern_lenght, &pattern_support);
	Pattern *p;
	p = new Pattern();
	p->support = pattern_support;
	p->length = pattern_lenght;
	int element;
	while(r == 2)
	{
		for(int i = 0; i < pattern_lenght; i++)
		{
			t = fscanf(fpout,"%d",&element);
			if(t < 1)
			{
				cout << "Error fscanf" << endl;
				exit(1);
			}
			p->PV[i] = element;
		}
		patternList.push_back(*p);
		r = fscanf(fpout,"%d;%d;",&pattern_lenght,&pattern_support);
		p = new Pattern();
		p->support = pattern_support;
		p->length = pattern_lenght;
	}
	fclose(fpout);

/*	// display mined patterns
	for(unsigned int i = 0; i < patternList.size(); i++)
	{
		cout << patternList[i].length << ";" << patternList[i].support << ";";
		for(int j = 0; j < patternList[i].length; j++)
			cout << patternList[i].PV[j] << " ";
		cout << endl;
	}*/
}

// build an offspring solution based on mined patterns
void mined_patterns_based_construct(long n, type_vector & child_sol)
{
	for(int i = 0; i <= n; i++)
		child_sol[i] = 0;

	// select a mined pattern based on tournament selection strategy
	short int tournament_pool[100];
	int tournament_pool_size = 4;
	// randomly select multiple patterns with replacement from patterns set

	for(int i = 0; i < tournament_pool_size; i++)
	{
		tournament_pool[i] = rand()%nbr_patterns;
	}

	// find out the longest patterns from these chosen patterns
	int max_length = -1;
	int index_longest;
	for(int i = 0; i < tournament_pool_size; i++)
	{
		if(patternList[tournament_pool[i]].length > max_length)
		{
			max_length = patternList[tournament_pool[i]].length;
			index_longest = tournament_pool[i];
		}
	}

	// build an offspring solution based on the selected pattern
	int *is_assigned;
	int *is_available;
	int *available_e;
	int nbr_assigned;
	int nbr_available_e;
	available_e = new int[n];
	is_assigned = new int[n+1];
	for(int i = 1; i <= n; i++)
		is_assigned[i] = 0;
	is_available = new int[n+1];
	for(int i = 1; i <= n; i++)
		is_available[i] = 1;

	int element;
	int x,y;
	nbr_assigned = 0;
	for(int i = 0; i < patternList[index_longest].length; i++)
	{
		element = patternList[index_longest].PV[i];
		x = element/n + 1;
		y = element - (x-1)*n + 1;
		child_sol[x] = y;
		is_assigned[x] = 1;
		is_available[y] = 0;
		nbr_assigned++;
	}

	nbr_available_e = 0;
	for(int i = 1; i <= n; i++)
		if(is_available[i] == 1)
		{
			available_e[nbr_available_e] = i;
			nbr_available_e++;
		}

	int index_v,choose_v;
	// randomly assign the remaining elements
	for(int i = 1; i <= n; i++)
		if(is_assigned[i] == 0)
		{
			index_v = rand()%nbr_available_e;
			choose_v = available_e[index_v];
			child_sol[i] = choose_v;
			is_assigned[i] = 1;
			nbr_assigned++;
			is_available[available_e[index_v]] = 0;

			nbr_available_e--;
			available_e[index_v] = available_e[nbr_available_e];
		}

	delete [] is_assigned;
	delete [] is_available;
	delete [] available_e;
}

void guided_and_mined_patterns_based_construct(long n, type_vector & child_sol)
{
	for(int i = 0; i <= n; i++)
		child_sol[i] = 0;

	// select a mined pattern based on tournament selection strategy
	short int tournament_pool[100];
	int tournament_pool_size = 4;
	// randomly select multiple patterns with replacement from patterns set
	for(int i = 0; i < tournament_pool_size; i++)
	{
		tournament_pool[i] = rand()%nbr_patterns;
	}

	// find out the longest patterns from these chosen patterns
	int max_length = -1;
	int index_longest;
	for(int i = 0; i < tournament_pool_size; i++)
	{
		if(patternList[tournament_pool[i]].length > max_length)
		{
			max_length = patternList[tournament_pool[i]].length;
			index_longest = tournament_pool[i];
		}
	}

	// build an offspring solution based on the selected pattern
	int *is_assigned;
	int *is_available;
	int *available_e;
	int nbr_assigned;
	int nbr_available_e;
	available_e = new int[n];
	is_assigned = new int[n+1];
	for(int i = 1; i <= n; i++)
		is_assigned[i] = 0;
	is_available = new int[n+1];
	for(int i = 1; i <= n; i++)
		is_available[i] = 1;

	// step 1.
	int element;
	int x,y;
	nbr_assigned = 0;
	for(int i = 0; i < patternList[index_longest].length; i++)
	{
		element = patternList[index_longest].PV[i];
		x = element/n + 1;
		y = element - (x-1)*n + 1;
		child_sol[x] = y;
		is_assigned[x] = 1;
		is_available[y] = 0;
	}

	// step 2.
	// complete the solution based an selected elite solution
	int index_choose_elite;
	index_choose_elite = rand()%PS;

	if(nbr_patterns > 4)
	{
		int elite_cost = Pop_costs[index_choose_elite];
		int nbr_select,index_sol;

		nbr_select = 1;
		while(nbr_select < max_nbr_selects)
		{
			index_sol = rand()%PS;
			if(Pop_costs[index_sol] < elite_cost)
			{
				elite_cost = Pop_costs[index_sol];
				index_choose_elite = index_sol;
			}
			nbr_select++;
		}
	}

	for(int i = 1; i <= n; i++)
		if(is_assigned[i] == 0)
		{
			element = Pop[index_choose_elite][i];
			if(is_available[element] == 1)
			{
				child_sol[i] = element;
				is_assigned[i] = 1;
				nbr_assigned++;
				is_available[element] = 0;
			}
		}

	// step 3
	nbr_available_e = 0;
	for(int i = 1; i <= n; i++)
		if(is_available[i] == 1)
		{
			available_e[nbr_available_e] = i;
			nbr_available_e++;
		}

	int index_v,choose_v;
	// randomly assign the remaining elements
	for(int i = 1; i <= n; i++)
		if(is_assigned[i] == 0)
		{
			index_v = rand()%nbr_available_e;
			choose_v = available_e[index_v];
			child_sol[i] = choose_v;
			is_assigned[i] = 1;
			nbr_assigned++;
			is_available[available_e[index_v]] = 0;

			nbr_available_e--;
			available_e[index_v] = available_e[nbr_available_e];
		}

	delete [] is_assigned;
	delete [] is_available;
	delete [] available_e;
}

// build an offspring solution based on the selected pattern
void solution_construct_based_mined_pattern(long n, int index_pattern, type_vector & child_sol)
{
	for(int i = 0; i <= n; i++)
		child_sol[i] = 0;

	// Step 1. build a partial solution based on mined frequent pattern
	int *is_assigned;
	int *is_available;
	int *available_e;
	int nbr_assigned;
	int nbr_available_e;
	available_e = new int[n];
	is_assigned = new int[n+1];
	for(int i = 1; i <= n; i++)
		is_assigned[i] = 0;
	is_available = new int[n+1];
	for(int i = 1; i <= n; i++)
		is_available[i] = 1;

	int element;
	int x,y;
	nbr_assigned = 0;
	for(int i = 0; i < patternList[index_pattern].length; i++)
	{
		element = patternList[index_pattern].PV[i];
		x = element/n + 1;
		y = element - (x-1)*n + 1;
		child_sol[x] = y;
		is_assigned[x] = 1;
		is_available[y] = 0;
	}

	// Step 2. guided by a reference or not
	if(patternList[index_pattern].length < 0.75*n)
	{
		// phase 1. select a good elite solution
		int index_choose_elite = rand()%PS;
		int elite_cost = Pop_costs[index_choose_elite];
		int nbr_select,index_sol;

		nbr_select = 1;
		while(nbr_select < max_nbr_selects)
		{
			index_sol = rand()%PS;
			if(Pop_costs[index_sol] < elite_cost)
			{
				elite_cost = Pop_costs[index_sol];
				index_choose_elite = index_sol;
			}
			nbr_select++;
		}

		// phase 2. complete the solution based an elite solution
		for(int i = 1; i <= n; i++)
			if(is_assigned[i] == 0)
			{
				element = Pop[index_choose_elite][i];
				if(is_available[element] == 1)
				{
					child_sol[i] = element;
					is_assigned[i] = 1;
					nbr_assigned++;
					is_available[element] = 0;
				}
			}
	}

	// Step 3. randomly assign the remaining elements
	nbr_available_e = 0;
	for(int i = 1; i <= n; i++)
		if(is_available[i] == 1)
		{
			available_e[nbr_available_e] = i;
			nbr_available_e++;
		}

	int index_v,choose_v;
	for(int i = 1; i <= n; i++)
		if(is_assigned[i] == 0)
		{
			index_v = rand()%nbr_available_e;
			choose_v = available_e[index_v];
			child_sol[i] = choose_v;
			is_assigned[i] = 1;
			nbr_assigned++;
			is_available[available_e[index_v]] = 0;

			nbr_available_e--;
			available_e[index_v] = available_e[nbr_available_e];
		}

	delete [] is_assigned;
	delete [] is_available;
	delete [] available_e;
}

void build_elite_population()
{
	int *sol;
	long sol_cost;
	double sol_time;
	sol = new int[n+1];
	int nbr_sol;

	nbr_sol = 0;
	while(nbr_sol < PS)
	{
    	// solution initialize
    	for(int j = 0; j <= n; j++)
    		sol[j] = j;

    	for(int j = 1; j < n; j++)
    		swap(sol[j], sol[j + rand()%(n-j+1)]);

		// local optimize
		breakout_local_search(n, flow, dist, sol, sol_cost, 10000, sol_time);
		Pop_costs[nbr_sol] = sol_cost;
		Pop_times[nbr_sol] = sol_time;

		for(int j = 1; j <= n; j++)
			Pop[nbr_sol][j] = sol[j];

		nbr_sol++;
    }

	int index_w;
	long max_cost = -1;
	int min_dist,sol_dist;
	while(nbr_sol < 2*PS)
	{
    	// a random permutation
    	for(int i = 0; i <= n; i++)
    		sol[i] = i;

    	for(int i = 1; i < n; i++)
    		swap(sol[i], sol[i + rand()%(n-i+1)]);

		// Breakout local search with max_iter = 5000
		breakout_local_search(n, flow, dist, sol, sol_cost, 10000, sol_time);

		// the distance to the closest individual in the population
		min_dist = max_int;
	    for(int i = 0; i < PS; i++)
	    {
	    	sol_dist = 0;
	    	for(int j = 1; j <= n; j++)
	    	{
	    		if(Pop[i][j] != sol[j])
	    			sol_dist++;
	        }

	        if(sol_dist < min_dist)
	        	min_dist = sol_dist;
	    }

		max_cost = -1;
		// find out the worst solution
		for(int i = 0; i < PS; i++)
			if(Pop_costs[i] > max_cost)
			{
				max_cost = Pop_costs[i];
				index_w = i;
			}

		// replace the worst solution
		if(min_dist > 0 && sol_cost < max_cost)
		{
			Pop_costs[index_w] = sol_cost;
			Pop_times[index_w] = sol_time;
			for(int i = 1; i <= n; i++)
				Pop[index_w][i] = sol[i];
		}
		nbr_sol++;
	}
}

bool is_unique_sol(type_vector & sol,int nbr_sol)
{
	bool is_unique = true;
	int sol_dist;
	for(int i = 0; i < nbr_sol; i++)
	{
		sol_dist = 0;
    	for(int j = 1; j <= n; j++)
    		if(sol[j] != Pop[i][j])
    			sol_dist++;

    	if(sol_dist == 0)
    	{
    		is_unique = false;
    		break;
    	}
	}

	return is_unique;
}

long build_unique_elite()
{
	int *sol;
	long sol_cost;
	double sol_time;
	sol = new int[n+1];
	int nbr_sol;

	nbr_sol = 0;
	while(nbr_sol < PS)
	{
    	// solution initialize
    	for(int j = 0; j <= n; j++)
    		sol[j] = j;

    	for(int j = 1; j < n; j++)
    		swap(sol[j], sol[j + rand()%(n-j+1)]);

		// local optimize
		breakout_local_search(n, flow, dist, sol, sol_cost, 10000, sol_time);

		if(is_unique_sol(sol,nbr_sol) == true)
		{
			Pop_costs[nbr_sol] = sol_cost;
			Pop_times[nbr_sol] = sol_time;

			for(int j = 1; j <= n; j++)
				Pop[nbr_sol][j] = sol[j];

			if(sol_cost < best_cost)
			{
				best_cost = sol_cost;
				best_time = sol_time;
		    	for(int i = 1; i <= n; i++)
		    		best_sol[i] = sol[i];
			}

			nbr_sol++;
		}

		if(best_cost <= best_known_cost)
			return best_cost;
    }

	int index_w;
	long max_cost = -1;
	int min_dist,sol_dist;
	while(nbr_sol < 2*PS)
	{
    	// a random permutation
    	for(int i = 0; i <= n; i++)
    		sol[i] = i;

    	for(int i = 1; i < n; i++)
    		swap(sol[i], sol[i + rand()%(n-i+1)]);

		// Breakout local search with max_iter = 5000
		breakout_local_search(n, flow, dist, sol, sol_cost, 10000, sol_time);

		// the distance to the closest individual in the population
		min_dist = max_int;
	    for(int i = 0; i < PS; i++)
	    {
	    	sol_dist = 0;
	    	for(int j = 1; j <= n; j++)
	    	{
	    		if(Pop[i][j] != sol[j])
	    			sol_dist++;
	        }

	        if(sol_dist < min_dist)
	        	min_dist = sol_dist;
	    }

		max_cost = -1;
		// find out the worst solution
		for(int i = 0; i < PS; i++)
			if(Pop_costs[i] > max_cost)
			{
				max_cost = Pop_costs[i];
				index_w = i;
			}

		// replace the worst solution
		if(min_dist > 0 && sol_cost < max_cost)
		{
			Pop_costs[index_w] = sol_cost;
			Pop_times[index_w] = sol_time;
			for(int i = 1; i <= n; i++)
				Pop[index_w][i] = sol[i];

			if(sol_cost < best_cost)
			{
				best_cost = sol_cost;
				best_time = sol_time;
		    	for(int i = 1; i <= n; i++)
		    		best_sol[i] = sol[i];
			}
		}

		if(best_cost <= best_known_cost)
			return best_cost;

		nbr_sol++;
	}
	return best_cost;
}

// data mining based memetic search algorithm
long FPBS_v0()
{
	int gens;
	int no_improve_gens = 0;
	int no_update;
	int max_no_update = 15;	// condition to start the data mining procedure
	double sol_time = 0.0;

	best_cost = max_int;

	// generate a set of initial solutions
	initialize_pool(n, PS, Pop);
	// local optimization each individual
	local_optimize(n, PS, Pop, Pop_costs, Pop_times,flow, dist, sol_time,10000);

	if(best_cost <= best_known_cost)
		return best_cost;

	// mine frequent patterns
	mine_frequent_patterns();

	gens = 0;
	best_gens = 0;
	while(((clock()-begin_time)/static_cast<double>(CLOCKS_PER_SEC)) < limit_time)
	{
		//printf("gen = %d, child_cost = %ld, best_cost = %ld\n",gens,child_cost,best_cost);
		// start data mining procedure or not
		if(no_update > max_no_update)
		{
			mine_frequent_patterns();
			no_update = 0;
		}

		// generate an offspring solution based on mined frequent patterns
		guided_and_mined_patterns_based_construct(n, child_sol);
		//mined_patterns_based_construct(n, child_sol);

		// Breakout local search with max_iter = 10000
		breakout_local_search(n, flow, dist, child_sol, child_cost, 10000, child_time);

		if(child_cost < best_cost)
		{
			no_improve_gens = 0;
			best_gens = gens;
		}
		else
			no_improve_gens++;

		// update the population
		if(update_pool_unique(n, child_sol, child_cost, child_time,Pop, Pop_costs, PS))
			no_update = 0;
		else
			no_update++;

		// check if it reaches the best known value
		if(best_cost <= best_known_cost)
			break;

		gens++;
	}
	return best_cost;
}

// data mining based memetic search algorithm
long FPBS_v1()
{
	int gens;
	int no_improve_gens = 0;
	int no_update;
	int nbr_mines;	// times to startup the data mining procedure
	int nbr_loops;
	bool stop_flag = false;
	best_cost = max_int;

	// Step 1. Initialization
	build_unique_elite();

	if(best_cost <= best_known_cost)
		return best_cost;

	// mine frequent patterns
	mine_frequent_patterns();
	nbr_mines = 1;

	gens = 0;
	best_gens = 0;
	nbr_loops = 0;
	while(stop_flag == false)
	{
		// Step 2. Solution construction based on mined frequent pattern
		no_update = 0;
		for(int i = 0; i < nbr_patterns; i++)
		{
			// construct a solution based on i-th pattern;
			solution_construct_based_mined_pattern(n,i,child_sol);

			// Breakout local search with max_iter = 10000
			breakout_local_search(n, flow, dist, child_sol, child_cost, 10000, child_time);

			// update the best solution found
			if(child_cost < best_cost)
			{
				no_improve_gens = 0;
				best_gens = gens;
			}
			else
				no_improve_gens++;

			// update the population
			if(update_pool_unique(n, child_sol, child_cost, child_time,Pop, Pop_costs, PS))
				no_update = 0;
			else
				no_update++;

			// check if it reaches the best known value
			if(best_cost <= best_known_cost)
			{
				stop_flag = true;
				break;
			}

			if(((clock()-begin_time)/static_cast<double>(CLOCKS_PER_SEC)) > limit_time)
			{
				stop_flag = true;
				break;
			}
			gens++;
			//printf("gen = %d, child_cost = %ld, best_cost = %ld\n",gens,child_cost,best_cost);
		}

		// Step 3. Data mining: startup data mining procedure when the elite set is stable
		if(no_update == nbr_patterns)
		{
			mine_frequent_patterns();
			nbr_mines++;
			no_update = 0;
		}
		nbr_loops++;
	}
	//cout << "nbr_loops = " << nbr_loops << ", Number of times to mine = " << nbr_mines << endl;
	return best_cost;
}

int main(int argc,char *argv[])
{
	if(argc == 6)
    {
		instance_name = argv[1];
		dataset = argv[2];
		best_known_cost = atoi(argv[3]);
		nbr_repeats = atoi(argv[4]);
		limit_time = atof(argv[5]);
    }
    else
    {
        cout << endl << "### Input the following parameters ###" << endl;
        cout << "<instance> <data set> <best known cost> <number of repeats> <limit time>" << endl;
        exit(0);
    }

	// instance file path
	strcpy(instance_path,"./instances/");
    strcat(instance_path,dataset);
    strcat(instance_path,"/");
	strcat(instance_path,instance_name);

	// statistical file path
	strcpy(statistic_path,"./statistics/");
    strcat(statistic_path,dataset);
    strcat(statistic_path,"/");
    strcat(statistic_path,instance_name);
    strcat(statistic_path,".2h_10k_10k.out");

    // read an instances
    read_instance();

    // initial jump magnitude of BLS, 0.05n for Type I, II and 0.15n for Type III, IV
    initial_ptr = determine_initial_ptr(instance_name);

	long sol_costs[nbr_repeats];
	double sol_times[nbr_repeats];
	long sol_gens[nbr_repeats];
	long best_cost_found = max_int; 	// best solution found so far
	type_vector best_sol_found;
	best_sol_found = new int[n+1];

	strcpy(elite_set_path,instance_name);
    strcat(elite_set_path,"_elites.txt");
	strcpy(pattern_set_path,instance_name);
    strcat(pattern_set_path,"_patterns.txt");

    // Repeat multiple runs
	//srand(1);
	printf("Instance: %s and Limit time = %lf\n",instance_name,limit_time);
	for(int i = 0; i < nbr_repeats; i++)
	{
		begin_time = clock();
		best_cost = 999999999999ULL;
		srand(time(NULL));

		// invoke the proposed FPBS algorithm
		FPBS_v1();

		sol_costs[i] = best_cost;
		sol_times[i] = best_time;
		sol_gens[i] = best_gens;

		if(best_cost < best_cost_found)
		{
			best_cost_found = best_cost;
			for(int j = 1; j <= n; j++)
				best_sol_found[j] = best_sol[j];
		}
	}

	// check and store the results
	output_results(n, statistic_path, sol_costs, nbr_repeats, best_cost_found, best_sol_found, sol_times,sol_gens);
	printf("finishing!\n");
	printf("best_cost = %ld\n",best_cost_found);
	// free memory
	delete [] best_sol_found;
	clear_up();
}

